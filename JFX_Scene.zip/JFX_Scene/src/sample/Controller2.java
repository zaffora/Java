package sample;

import javafx.event.ActionEvent;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.scene.control.ListView;
import javafx.collections.FXCollections;
import java.net.URL;
import java.util.ResourceBundle;

public class Controller2 implements Initializable{

    @Override
    public void initialize(URL location, ResourceBundle resources) {

    }
}
