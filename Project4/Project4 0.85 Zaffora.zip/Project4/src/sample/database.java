package sample;

public class database {

    String app, reviews;
    double rating;

    public database(){}

    public database(double rating, String app){
        this.rating = rating;
        this.app = app;
    }

    public String getApp() {
        return app;
    }

    public void setApp(String app) {
        this.app = app;
    }

    public double getRating() {
        return rating;
    }

    public void setRating(double rating) {
        this.rating = rating;
    }

    public void setReviews(String reviews){this.reviews = reviews;}

    public String getReviews(){return reviews;}



    @Override
    public String toString(){
        String output = "";
        output += app + ", Rating: " + rating + " , Review: " + reviews;
        //return "Application Name: " + String.format("%s", app)  + "\nRating: " + String.format("%d", rating);
        return output;
    }
}
