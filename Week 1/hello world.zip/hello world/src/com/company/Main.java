// Domenico Zaffora
// ITN261-401 8/28/19
package com.company;

public class Main {

    public static void main(String[] args) {
        System.out.println("Hello My N ame is Domenico Zaffora");
    }
}
