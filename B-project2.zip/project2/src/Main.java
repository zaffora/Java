// Bethany Cacayorin
// Programming II: Project 2
// October 18, 2019

// Import Libraries
import java.util.Scanner;

public class Main {
    public static void main(String[] args){

        // Player's constructor should initialize the Player
        // Initial location
        Player p1 = new Player();

        // Obstacle's constructor should initialize the obstacle
        // to random location - which cannot overlap with p1 at 0, 0
        Obstacle obstacle = new Obstacle();

        // after the following statement, name will have a valid name
        // In other words, getValidName will have input validation
        String name = getValidName();
        p1.setName(name);

        // After the following statements, the screen should display
        // the player's name and position as well as the obstacle position
        gameStatus(p1, obstacle);
    }

    // this is to check if the user input a valid name
    private static String getValidName(){
        String name = "null";

        Scanner input = new Scanner(System.in);
        do {
            System.out.print("Please enter a valid name " +
                    "(must start with a letter and be less than 15 characters):");
            name = input.next();
        }
        while (name.length() > 15 );
        return name;
    }

    // this will printout the status of the user
    private static void gameStatus(Player name, Obstacle obstacle){
        // generates random number for objective's location
        int x = (int) (Math.random() * 7);
        int y = (int) (Math.random() * 11);

        // this will generate the field
        GameObject.gameField();

        // Prints out the details
        System.out.println("Game Status: ");
        System.out.println("\tPlayer name: " + name);
        System.out.println("\tCar Position: ");

        // sets the player's location
        name.setLocation(0, 0);
        int pX = name.getX();
        int pY = name.getY();


        // sets the obstacle location
        // do-while so it will not generate (0, 0)
        do {obstacle.setLocation(x, y);}
        while (x == 0 && y == 0);
        //obstacle.getLocation();
        int oX = obstacle.getX();
        int oY = obstacle.getY();

        // this will print the game field
        GameObject.printDash(pX, pY, oX, oY);
    }

}

