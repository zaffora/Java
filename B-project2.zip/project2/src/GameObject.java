// Game object class

class GameObject {
    int x;
    int y;

    // initialization of the game field
    //ArrayList<String> dashes = new ArrayList<String>();
    static String [][] dashes = new String[6][10];
    static String dash = " - ";

    // this generates the dashes in the game field
    public static String[][] gameField(){
        // This will pint out x the obstacle course
        for (int i = 0; i < 6; i++) {
            //System.out.println();
            for (int j = 0; j < 10; j++) {
                dashes[i][j] = dash;
                //System.out.print(dashes[i][j]);
            }
        }
        return dashes;
    }

    static void printDash(int pX, int pY, int oX, int oY){
        // replacing the value of Player location
        dashes [pX][pY] = ("  P ");

        // replacing the value of obstacle location
        dashes [oX][oY] = ("  O ");

        // prints the game field
        for (int i = 0; i < 6; i++) {
            System.out.println();
            for (int j = 0; j < 10; j++) {
                //dashes[i][j] = dash;
                System.out.print(dashes[i][j]);
            }
        }
    }
}
