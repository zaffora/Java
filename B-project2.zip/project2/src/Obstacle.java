// Obstacle subclass of game object

class Obstacle extends GameObject{
    private int x = 0;
    private int y =  0;
    // Math.random() * 25 + 5

    void setLocation(int x, int y){
        this.x = x;
        this.y = y;
        // prints the location
        System.out.println("  Obstacles: " + x + " " + y);
    }

    Integer getX(){
        return x;
    }
    Integer getY(){
        return y;
    }
}
