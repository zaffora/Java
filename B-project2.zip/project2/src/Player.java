// pLayer subclass of game object

class Player extends GameObject {

    private String name;
    private int x = 0;
    private int y =  0;

    void setName(String name) {
        this.name = name;
    }

    public String toString(){
        return name;
    }

    void setLocation(int x, int y){
        this.x = x;
        this.y = y;
        // prints the location
        System.out.println("  Player: " + x + " " + y);

    }

    Integer getX(){
        return x;
    }
    Integer getY(){
        return y;
    }
}